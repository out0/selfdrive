#pragma once

#ifndef __COORD_CONVERSION_DRIVELESS_H
#define __COORD_CONVERSION_DRIVELESS_H

#include "waypoint.h"
#include "world_pose.h"
#include "map_pose.h"
#include <cmath>


class CoordinateConverter
{
private:
    float _world_coord_scale;
    angle _origin_compass_angle;
    float _rateW;
    float _rateH;
    float _invRateW;
    float _invRateH;
    int _width;
    int _height;
    float _perceptionWidthSize_m;
    float _perceptionHeightSize_m;

    double __convert_map_heading_to_compass(double h);
    double __convert_compass_to_map_heading(double hc);

    int _waypoint_coord_origin_x;
    int _waypoint_coord_origin_z;


public:
    CoordinateConverter(WorldPose &origin, int width, int height, float perceptionWidthSize_m, float perceptionHeightSize_m);

    MapPose convert (WorldPose &pose);
    WorldPose convert (MapPose &pose);

    Waypoint convert (MapPose &location, MapPose &target);
    MapPose convert (MapPose &location, Waypoint &pose);

    int width() { return _width; };
    int height() { return _height; };
    float perceptionWidthSize_m() { return _perceptionWidthSize_m; };
    float perceptionHeightSize_m() { return _perceptionHeightSize_m; };
    void setWaypointCoordinateOrigin(int x, int z);
};



#endif
