#include "../../include/search_frame.h"
#include "../../include/cuda_basic.h"
#include "../search_frame_params.h"
#include <stdexcept>

extern __device__ __host__ bool __computeFeasibleForAngle(float3 *frame, int *params, float *classCost, int minDistX, int minDistZ, int x, int z, float angle_radians);
extern std::pair<int, int> __checkTraversableAngleBitPairCheck(float heading_rad);
extern __device__ __host__ bool CHECK_OUT_BOUNDARIES(int width, int height, int x, int z);
extern __device__ __host__ void setObstacle(float3 *frame, int width, int height, int x, int z);
extern __device__ __host__ bool isObstacle(float3 *frame, float *classCosts, int width, int height, int x, int z);
extern __device__ __host__ void propagateObstacleInRegion(float3 *frame, const int width, const int height, const int minDistance, int x_start, int z_start);
extern __device__ __host__ void propagateObstacleLeft(float3 *frame, const int width, const int height, const int minDistance, int x_start, int z_start);
extern __device__ __host__ void propagateObstacleRight(float3 *frame, const int width, const int height, const int minDistance, int x_start, int z_start);
extern __device__ __host__ void propagateObstacleTop(float3 *frame, const int width, const int height, const int minDistance, int x_start, int z_start);
extern __device__ __host__ void propagateObstacleBottom(float3 *frame, const int width, const int height, const int minDistance, int x_start, int z_start);
extern __device__ __host__ void propagateMinDistance(float3 *frame, float *classCosts, const int width, const int height, const int minDistance, int pos, int x, int z);

std::pair<int, int> SearchFrame::checkTraversableAngleBitPairCheck(float heading_rad)
{
    return __checkTraversableAngleBitPairCheck(heading_rad);
}

__global__ void __CUDA_safe_distance_prepare(float3 *frame, float *classCosts, int *_searchSpaceParams, int half_minDist_px)
{
    int pos = blockIdx.x * blockDim.x + threadIdx.x;

    int width = _searchSpaceParams[FRAME_PARAM_WIDTH];
    int height = _searchSpaceParams[FRAME_PARAM_HEIGHT];
    int lower_bound_ego_x = _searchSpaceParams[FRAME_PARAM_LOWER_BOUND_X];
    int lower_bound_ego_z = _searchSpaceParams[FRAME_PARAM_LOWER_BOUND_Z];
    int upper_bound_ego_x = _searchSpaceParams[FRAME_PARAM_UPPER_BOUND_X];
    int upper_bound_ego_z = _searchSpaceParams[FRAME_PARAM_UPPER_BOUND_Z];

    if (pos >= width * height)
        return;

    int z = pos / width;
    int x = pos - z * width;
    // int dx = x - goal_x;
    // int dz = z - goal_z;

    // frame[pos].y = sqrtf(dx * dx + dz * dz);

    // turns on the obstacle propagation-based traversability bit and off the angle-based bits (0001 0000 0000)
    // because the obstacle propagation-based works by propagating obstacles as turning bits off, while the
    // angle-based check works by checking each angle and turning the respective bit on as it is traversable.
    frame[pos].z = 256.0;

    if (x >= lower_bound_ego_x && x <= upper_bound_ego_x && z >= upper_bound_ego_z && z <= lower_bound_ego_z)
        return;

    const int nodeClass = TO_INT(frame[pos].x);
    if (classCosts[nodeClass] < 0)
    {
        frame[pos].z = 0x0;
    }
}

__global__ void __CUDA_safe_distance_obstacle_expansion_based(float3 *frame, float *classCosts, int *_searchSpaceParams, int half_minDist_px)
{
    int pos = blockIdx.x * blockDim.x + threadIdx.x;
    int width = _searchSpaceParams[FRAME_PARAM_WIDTH];
    int height = _searchSpaceParams[FRAME_PARAM_HEIGHT];
    int lower_bound_ego_x = _searchSpaceParams[FRAME_PARAM_LOWER_BOUND_X];
    int lower_bound_ego_z = _searchSpaceParams[FRAME_PARAM_LOWER_BOUND_Z];
    int upper_bound_ego_x = _searchSpaceParams[FRAME_PARAM_UPPER_BOUND_X];
    int upper_bound_ego_z = _searchSpaceParams[FRAME_PARAM_UPPER_BOUND_Z];

    if (pos >= width * height)
        return;

    int z = pos / width;
    int x = pos - z * width;

    if (x >= lower_bound_ego_x && x <= upper_bound_ego_x && z >= upper_bound_ego_z && z <= lower_bound_ego_z)
        return;

    const int nodeClass = TO_INT(frame[pos].x);

    if (classCosts[nodeClass] < 0)
    {
        // printf("[CUDA] pos %d, %d will propagate distance %d\n", x, z, half_minDist_px);
        propagateMinDistance(frame, classCosts, width, height, half_minDist_px, pos, x, z);
    }
}

__global__ void __CUDA_safe_distance_vector_based(float3 *frame, float *classCosts, int *_searchSpaceParams, int minDistX, int minDistZ)
{
    int pos = blockIdx.x * blockDim.x + threadIdx.x;
    int width = _searchSpaceParams[FRAME_PARAM_WIDTH];
    int height = _searchSpaceParams[FRAME_PARAM_HEIGHT];
    int lower_bound_ego_x = _searchSpaceParams[FRAME_PARAM_LOWER_BOUND_X];
    int lower_bound_ego_z = _searchSpaceParams[FRAME_PARAM_LOWER_BOUND_Z];
    int upper_bound_ego_x = _searchSpaceParams[FRAME_PARAM_UPPER_BOUND_X];
    int upper_bound_ego_z = _searchSpaceParams[FRAME_PARAM_UPPER_BOUND_Z];

    if (pos >= width * height)
        return;

    int z = pos / width;
    int x = pos - z * width;

    if (x >= lower_bound_ego_x && x <= upper_bound_ego_x && z >= upper_bound_ego_z && z <= lower_bound_ego_z)
    {
        frame[pos].z = 0.0 + (TO_INT(frame[pos].z) | 0xff);
        return;
    }

    const int nodeClass = TO_INT(frame[pos].x);

    if (classCosts[nodeClass] < 0)
        return;

    int v = 0;
    for (int i = 0; i < 8; i++)
    {
        if (__computeFeasibleForAngle(frame, _searchSpaceParams, classCosts, minDistX, minDistZ, x, z, TRAVERSABILITY_ANGLES[i]))
            v = v | TRAVERSABILITY_BITS[i];
    }

    frame[pos].z = 0.0 + (TO_INT(frame[pos].z) | v);
}

void SearchFrame::processSafeDistanceZone(std::pair<int, int> minDistance, bool computeVectorized)
{
    int size = width() * height();
    int numBlocks = floor(size / THREADS_IN_BLOCK) + 1;

    _params->get()[FRAME_PARAM_MIN_DIST_X] = 0.5 * minDistance.first;
    _params->get()[FRAME_PARAM_MIN_DIST_Z] = 0.5 * minDistance.second;

    int min_x = _params->get()[FRAME_PARAM_MIN_DIST_X];
    int min_z = _params->get()[FRAME_PARAM_MIN_DIST_Z];

    int minDist_px = TO_INT(sqrtf(min_x * min_x + min_z * min_z));

    __CUDA_safe_distance_prepare<<<numBlocks, THREADS_IN_BLOCK>>>(getPtr(), _classCosts->get(), _params->get(), minDist_px);
    CUDA(cudaDeviceSynchronize());

    __CUDA_safe_distance_obstacle_expansion_based<<<numBlocks, THREADS_IN_BLOCK>>>(getPtr(), _classCosts->get(), _params->get(), minDist_px);
    CUDA(cudaDeviceSynchronize());

    _safeZoneChecked = true;

    if (computeVectorized)
    {
        __CUDA_safe_distance_vector_based<<<numBlocks, THREADS_IN_BLOCK>>>(getPtr(), _classCosts->get(), _params->get(), min_x, min_z);
        CUDA(cudaDeviceSynchronize());
        _safeZoneVectorialChecked = true;
    }
}

__global__ void __CUDA_distance_to_goal(float3 *frame, float *classCosts, int *_searchSpaceParams, int goal_x, int goal_z)
{
    int pos = blockIdx.x * blockDim.x + threadIdx.x;
    int width = _searchSpaceParams[FRAME_PARAM_WIDTH];
    int height = _searchSpaceParams[FRAME_PARAM_HEIGHT];
    int lower_bound_ego_x = _searchSpaceParams[FRAME_PARAM_LOWER_BOUND_X];
    int lower_bound_ego_z = _searchSpaceParams[FRAME_PARAM_LOWER_BOUND_Z];
    int upper_bound_ego_x = _searchSpaceParams[FRAME_PARAM_UPPER_BOUND_X];
    int upper_bound_ego_z = _searchSpaceParams[FRAME_PARAM_UPPER_BOUND_Z];

    if (pos >= width * height)
        return;

    int z = pos / width;
    int x = pos - z * width;

    if (x < lower_bound_ego_x || x > upper_bound_ego_x || z < upper_bound_ego_z || z > lower_bound_ego_z)
    {
        const int nodeClass = TO_INT(frame[pos].x);
        if (classCosts[nodeClass] < 0)
        {
            frame[pos].y = 999999999;
            return;
        }
    }

    float dx = goal_x - x;
    float dz = goal_z - z;

    frame[pos].y = sqrtf(dx * dx + dz * dz);
}

void SearchFrame::processDistanceToGoal(int x, int z)
{
    int size = width() * height();
    int numBlocks = floor(size / THREADS_IN_BLOCK) + 1;

    if (_classCosts->get() == nullptr)
    {
        throw std::runtime_error("Class costs were not set. Please set costs before processing distance to goal.");
    }

    __CUDA_distance_to_goal<<<numBlocks, THREADS_IN_BLOCK>>>(getPtr(), _classCosts->get(), _params->get(), x, z);
    CUDA(cudaDeviceSynchronize());
    _distanceToGoalProcessed = true;
}

float SearchFrame::getDistanceToGoal(int x, int z)
{
    float3 *ptr = getPtr();
    return ptr[z * width() + x].y;
}